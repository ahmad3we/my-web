-- ============================================================
-- إنشاء الحسابات الأولية (شغّله بعد ملف 1-schema.sql)
-- قبل التشغيل: استبدل كل كلمة PASSWORD_... بكلمة المرور الحقيقية للحساب
-- (6 أحرف فأكثر، ويفضّل 8+). أسماء المستخدمين هي نفسها المستخدمة سابقاً.
-- ============================================================

select public._create_user('rawat.manager', 'المدير العام',                                 'admin',  null, 'PASSWORD_MANAGER');
select public._create_user('amiriya',       'مسؤول الفرع الرئيسي – بغداد العامرية',        'branch', 0,    'PASSWORD_AMIRIYA');
select public._create_user('ramadi',        'مسؤول الرمادي – شارع الملعب',                  'branch', 1,    'PASSWORD_RAMADI');
select public._create_user('ghazaliya',     'مسؤول بغداد – الغزالية',                       'branch', 2,    'PASSWORD_GHAZALIYA');
select public._create_user('fallujah1',     'مسؤول الفلوجة – شارع جيش الشعبي',              'branch', 3,    'PASSWORD_FALLUJAH1');
select public._create_user('fallujah2',     'مسؤول الفلوجة – قرب مجسر الحبانية',            'branch', 4,    'PASSWORD_FALLUJAH2');
select public._create_user('hawija',        'مسؤول كركوك – الحويجة',                        'branch', 5,    'PASSWORD_HAWIJA');
