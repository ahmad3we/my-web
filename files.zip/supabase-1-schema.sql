-- ============================================================
-- روعة الغيداق – إعداد قاعدة البيانات (شغّله مرة واحدة)
-- Supabase → SQL Editor → New query → الصق الملف كاملاً → Run
-- ============================================================

-- 1) الجداول -------------------------------------------------
create table if not exists public.profiles (
  id        uuid primary key references auth.users(id) on delete cascade,
  username  text unique not null,
  name      text not null,
  role      text not null default 'branch' check (role in ('admin','branch')),
  br        int,
  perms     jsonb not null default '{"add":1,"edit":1,"del":0}'
);

create table if not exists public.trips (
  id text primary key,
  d  jsonb not null,
  updated_at timestamptz not null default now()
);

create table if not exists public.daily (
  id text primary key,
  br int  not null,
  d  jsonb not null,
  updated_at timestamptz not null default now()
);

create table if not exists public.pil (
  id text primary key,
  br int  not null,
  d  jsonb not null,
  updated_at timestamptz not null default now()
);

create table if not exists public.logs (
  id bigint generated always as identity primary key,
  t  timestamptz not null default now(),
  u  text,
  a  text
);

create index if not exists pil_br_idx   on public.pil(br);
create index if not exists daily_br_idx on public.daily(br);

-- تحديث updated_at تلقائياً عند أي تعديل
create or replace function public.touch() returns trigger
language plpgsql as $$
begin new.updated_at := now(); return new; end $$;

drop trigger if exists t_touch on public.trips;
create trigger t_touch before update on public.trips for each row execute function public.touch();
drop trigger if exists t_touch on public.daily;
create trigger t_touch before update on public.daily for each row execute function public.touch();
drop trigger if exists t_touch on public.pil;
create trigger t_touch before update on public.pil for each row execute function public.touch();

-- 2) دوال مساعدة للصلاحيات -----------------------------------
create or replace function public.rg_role() returns text
language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid() $$;

create or replace function public.rg_br() returns int
language sql stable security definer set search_path = public as $$
  select br from public.profiles where id = auth.uid() $$;

create or replace function public.rg_perm(k text) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(
    (select role = 'admin' or coalesce(perms ->> k, '0') in ('1','true')
       from public.profiles where id = auth.uid()),
    false) $$;

-- 3) تفعيل RLS (عزل البيانات بين الفروع) ---------------------
alter table public.profiles enable row level security;
alter table public.trips    enable row level security;
alter table public.daily    enable row level security;
alter table public.pil      enable row level security;
alter table public.logs     enable row level security;

-- profiles: كل مستخدم يرى حسابه، والمدير يرى الكل ويعدّل الصلاحيات
drop policy if exists p_sel on public.profiles;
create policy p_sel on public.profiles for select to authenticated
  using (id = auth.uid() or public.rg_role() = 'admin');
drop policy if exists p_upd on public.profiles;
create policy p_upd on public.profiles for update to authenticated
  using (public.rg_role() = 'admin') with check (public.rg_role() = 'admin');

-- trips: الكل يقرأ (أي حساب مفعّل)، المدير فقط يكتب
drop policy if exists t_sel on public.trips;
create policy t_sel on public.trips for select to authenticated
  using (public.rg_role() is not null);
drop policy if exists t_ins on public.trips;
create policy t_ins on public.trips for insert to authenticated
  with check (public.rg_role() = 'admin');
drop policy if exists t_upd on public.trips;
create policy t_upd on public.trips for update to authenticated
  using (public.rg_role() = 'admin') with check (public.rg_role() = 'admin');
drop policy if exists t_del on public.trips;
create policy t_del on public.trips for delete to authenticated
  using (public.rg_role() = 'admin');

-- daily: المدير كل الفروع، مسؤول الفرع فرعه فقط وبحسب صلاحياته
drop policy if exists d_sel on public.daily;
create policy d_sel on public.daily for select to authenticated
  using (public.rg_role() = 'admin' or br = public.rg_br());
drop policy if exists d_ins on public.daily;
create policy d_ins on public.daily for insert to authenticated
  with check (public.rg_role() = 'admin' or (br = public.rg_br() and public.rg_perm('add')));
drop policy if exists d_upd on public.daily;
create policy d_upd on public.daily for update to authenticated
  using      (public.rg_role() = 'admin' or (br = public.rg_br() and public.rg_perm('edit')))
  with check (public.rg_role() = 'admin' or (br = public.rg_br() and public.rg_perm('edit')));
drop policy if exists d_del on public.daily;
create policy d_del on public.daily for delete to authenticated
  using (public.rg_role() = 'admin' or (br = public.rg_br() and public.rg_perm('del')));

-- pil (المعتمرون): نفس منطق daily
drop policy if exists m_sel on public.pil;
create policy m_sel on public.pil for select to authenticated
  using (public.rg_role() = 'admin' or br = public.rg_br());
drop policy if exists m_ins on public.pil;
create policy m_ins on public.pil for insert to authenticated
  with check (public.rg_role() = 'admin' or (br = public.rg_br() and public.rg_perm('add')));
drop policy if exists m_upd on public.pil;
create policy m_upd on public.pil for update to authenticated
  using      (public.rg_role() = 'admin' or (br = public.rg_br() and public.rg_perm('edit')))
  with check (public.rg_role() = 'admin' or (br = public.rg_br() and public.rg_perm('edit')));
drop policy if exists m_del on public.pil;
create policy m_del on public.pil for delete to authenticated
  using (public.rg_role() = 'admin' or (br = public.rg_br() and public.rg_perm('del')));

-- logs: أي حساب مفعّل يضيف، المدير فقط يقرأ
drop policy if exists l_ins on public.logs;
create policy l_ins on public.logs for insert to authenticated
  with check (public.rg_role() is not null);
drop policy if exists l_sel on public.logs;
create policy l_sel on public.logs for select to authenticated
  using (public.rg_role() = 'admin');

-- 4) توقيع المزامنة (يجعل التحديث التلقائي خفيفاً) -----------
create or replace function public.sync_sig() returns jsonb
language sql stable as $$
  select jsonb_build_object(
    'trips', (select count(*)::text || ':' || coalesce(max(updated_at)::text, '') from public.trips),
    'daily', (select count(*)::text || ':' || coalesce(max(updated_at)::text, '') from public.daily),
    'pil',   (select count(*)::text || ':' || coalesce(max(updated_at)::text, '') from public.pil),
    'prof',  (select count(*)::text || ':' || md5(coalesce(string_agg(
                 username || name || coalesce(br::text, '') || perms::text, ',' order by username), ''))
               from public.profiles)
  ) $$;

-- 5) إدارة الحسابات (للمدير العام فقط) -----------------------
-- دالة داخلية لإنشاء مستخدم (لا تُستدعى من المتصفح)
create or replace function public._create_user(
  p_username text, p_name text, p_role text, p_br int, p_password text) returns void
language plpgsql security definer set search_path = public, auth, extensions as $$
declare
  uid uuid := gen_random_uuid();
  em  text := lower(p_username) || '@rawat.app';
begin
  if exists (select 1 from public.profiles where username = lower(p_username)) then
    return;
  end if;
  insert into auth.users (
    instance_id, id, aud, role, email, encrypted_password, email_confirmed_at,
    raw_app_meta_data, raw_user_meta_data, created_at, updated_at,
    confirmation_token, recovery_token, email_change_token_new, email_change)
  values (
    '00000000-0000-0000-0000-000000000000', uid, 'authenticated', 'authenticated', em,
    crypt(p_password, gen_salt('bf')), now(),
    '{"provider":"email","providers":["email"]}', '{}', now(), now(), '', '', '', '');
  insert into auth.identities (
    id, user_id, provider_id, identity_data, provider, last_sign_in_at, created_at, updated_at)
  values (
    gen_random_uuid(), uid, uid::text,
    jsonb_build_object('sub', uid::text, 'email', em, 'email_verified', true),
    'email', now(), now(), now());
  insert into public.profiles (id, username, name, role, br, perms)
  values (uid, lower(p_username), p_name, p_role, p_br,
    case when p_role = 'admin' then '{"add":1,"edit":1,"del":1}'::jsonb
         else '{"add":1,"edit":1,"del":0}'::jsonb end);
end $$;

create or replace function public.admin_create_user(
  p_username text, p_name text, p_br int, p_password text) returns void
language plpgsql security definer set search_path = public, auth, extensions as $$
begin
  if public.rg_role() is distinct from 'admin' then raise exception 'not allowed'; end if;
  if p_username !~ '^[A-Za-z0-9_.]{3,}$' then raise exception 'bad username'; end if;
  if length(p_password) < 6 then raise exception 'password too short'; end if;
  if p_br is null or p_br < 0 or p_br > 5 then raise exception 'bad branch'; end if;
  if exists (select 1 from public.profiles where username = lower(p_username)) then
    raise exception 'username exists';
  end if;
  perform public._create_user(p_username, p_name, 'branch', p_br, p_password);
end $$;

create or replace function public.admin_set_password(p_username text, p_password text) returns void
language plpgsql security definer set search_path = public, auth, extensions as $$
declare v uuid;
begin
  if public.rg_role() is distinct from 'admin' then raise exception 'not allowed'; end if;
  if length(p_password) < 6 then raise exception 'password too short'; end if;
  select id into v from public.profiles where username = lower(p_username);
  if v is null then raise exception 'user not found'; end if;
  update auth.users set encrypted_password = crypt(p_password, gen_salt('bf')), updated_at = now()
   where id = v;
end $$;

create or replace function public.admin_delete_user(p_username text) returns void
language plpgsql security definer set search_path = public, auth, extensions as $$
declare v uuid;
begin
  if public.rg_role() is distinct from 'admin' then raise exception 'not allowed'; end if;
  select id into v from public.profiles where username = lower(p_username) and role <> 'admin';
  if v is null then raise exception 'user not found'; end if;
  delete from auth.users where id = v;
end $$;

-- 6) الأذونات ------------------------------------------------
grant usage on schema public to anon, authenticated;
grant select, insert, update, delete on public.profiles, public.trips, public.daily, public.pil, public.logs to authenticated;
grant usage, select on all sequences in schema public to authenticated;

revoke all on function public._create_user(text, text, text, int, text) from public, anon, authenticated;
revoke all on function public.admin_create_user(text, text, int, text) from public, anon;
revoke all on function public.admin_set_password(text, text) from public, anon;
revoke all on function public.admin_delete_user(text) from public, anon;
grant execute on function public.admin_create_user(text, text, int, text) to authenticated;
grant execute on function public.admin_set_password(text, text) to authenticated;
grant execute on function public.admin_delete_user(text) to authenticated;
grant execute on function public.sync_sig() to authenticated;
grant execute on function public.rg_role(), public.rg_br(), public.rg_perm(text) to authenticated;
